﻿using System;
using System.Web;
using System.IO;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Configuration;
using System.Net.Http.Headers;
using Locus.Core.Models;

namespace LocustSwarm
{
    class BackupService
    {
        private Timer _timer = null;
        static Backup generatedBackup = new Backup();
        
        // Create an HttpClient instance
        static HttpClient client = new HttpClient();

        static string baseAddressValue = ConfigurationManager.AppSettings["BaseAddress"];
        static string AccessToken = ConfigurationManager.AppSettings["AccessToken"];
        
        //private FileSystemWatcher _watcher;

        public bool Start()
        {
            // Pass in the time you want to start and the interval
            StartTimer(new TimeSpan(5, 0, 0), new TimeSpan(24, 0, 0));
            return true;
        }

        public bool Stop()
        {
            return true;
        }

        public void StartTimer(TimeSpan scheduledRunTime, TimeSpan timeBetweenEachRun)
        {
            // Initialize timer
            double current = DateTime.Now.TimeOfDay.TotalMilliseconds;
            double scheduledTime = scheduledRunTime.TotalMilliseconds;
            double intervalPeriod = timeBetweenEachRun.TotalMilliseconds;
            // calculates the first execution of the method, either its today at the scheduled time or tomorrow (if scheduled time has already occurred today)
            double firstExecution = current > scheduledTime ? intervalPeriod - (current - scheduledTime) : scheduledTime - current;

            // create callback - this is the method that is called on every interval
            TimerCallback callback = new TimerCallback(Connect);

            // create timer
            _timer = new Timer(callback, null, Convert.ToInt32(firstExecution), Convert.ToInt32(intervalPeriod));
        }

        // Start async method
        public void Connect(Object state)
        {
            RunAsync().GetAwaiter().GetResult();
        }

        // 
        static async Task RunAsync()
        {
            client.BaseAddress = new Uri(baseAddressValue);
            client.DefaultRequestHeaders.Accept.Clear();

            // Add an Accept header for JSON format
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.DefaultRequestHeaders.Add("Token", AccessToken);

            try
            {
                var url = await GenerateBackupAsync();
                Console.WriteLine($"Created at {url}");
            } catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            Console.ReadLine();
        }

        // Generate Backup method
        static async Task<Uri> GenerateBackupAsync()
        {
            HttpResponseMessage response = await client.PostAsJsonAsync("/api/Locust/GenerateBackup", generatedBackup);
            if (response.IsSuccessStatusCode)
            {
                var result = response.Content.ReadAsStringAsync().Result;
                generatedBackup = Newtonsoft.Json.JsonConvert.DeserializeObject<Backup>(result);

                // CREATE SUCCESS LOG 
                Console.WriteLine("Backup " + generatedBackup.Name + " successfully created at " + generatedBackup.Creation_Date);

                // return URI of the created resource.
                return response.Headers.Location;
            } else
            {
                response.EnsureSuccessStatusCode();
                return response.Headers.Location;
            }

        }

        // Download Backups
        public static byte[] DownloadBackup(Backup generatedBackup)
        {
            var path = baseAddressValue + "App_Data/"+generatedBackup.Name;

            using (MemoryStream ms = new MemoryStream())
            {
                using (FileStream file = new FileStream(path, FileMode.Open, FileAccess.Read))
                {
                    byte[] bytes = new byte[file.Length];
                    file.Read(bytes, 0, (int)file.Length);
                    ms.Write(bytes, 0, (int)file.Length);
                    return bytes;
                }
            }
        }

        // Get Backups 
        static async Task<Backup> GetBackupAsync(string path)
        {
            Backup backup = null;
            HttpResponseMessage response = await client.GetAsync(path);
            if (response.IsSuccessStatusCode)
            {
                backup = await response.Content.ReadAsAsync<Backup>();
            }
            return backup;
        }
    }
}